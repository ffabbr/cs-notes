# IncreasingDigits

Implement the method in `src/main/java/Recursion.java` recursively.
