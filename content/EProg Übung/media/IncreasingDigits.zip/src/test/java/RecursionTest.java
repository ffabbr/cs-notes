import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class RecursionTest {


    @Test
    public void digitsIncreasingAcceptsSingleDigits() {
        assertTrue(Recursion.digitsIncreasing(0));
        assertTrue(Recursion.digitsIncreasing(7));
    }

    @Test
    public void digitsIncreasingRecognizesIncreasingSequences() {
        assertTrue(Recursion.digitsIncreasing(10));
        assertTrue(Recursion.digitsIncreasing(21));
        assertTrue(Recursion.digitsIncreasing(9631));
        assertTrue(Recursion.digitsIncreasing(876543210));
    }

    @Test
    public void digitsIncreasingRejectsOtherSequences() {
        assertFalse(Recursion.digitsIncreasing(11));
        assertFalse(Recursion.digitsIncreasing(1234));
        assertFalse(Recursion.digitsIncreasing(9931));
        assertFalse(Recursion.digitsIncreasing(59631));
    }
}
