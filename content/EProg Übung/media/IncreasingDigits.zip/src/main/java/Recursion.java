public class Recursion {

    public static void main(String[] args) {
        System.out.println("digitsIncreasing(9631): expected true, received " + digitsIncreasing(9631));
    }

    public static boolean digitsIncreasing(int n) {
        // TODO: Implement this method recursively.
        return false;
    }

}
