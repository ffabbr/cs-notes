rootProject.name = "Recursion-IncreasingDigits"
