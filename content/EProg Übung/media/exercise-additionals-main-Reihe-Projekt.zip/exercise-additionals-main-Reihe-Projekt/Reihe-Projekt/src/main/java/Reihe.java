public class Reihe {

    public static void main(String[] args) {
        int n = 4;

        System.out.println("Für N = " + n + " sollte das Programm ca. 1.42 ausgeben.");
        System.out.println("Die Methode reihe(" + n + ") gibt " + reihe(n) + " aus.");
    }

    public static double reihe(int n) {
        // TODO: Berechnen Sie 1/1^2 + 1/2^2 + ... + 1/n^2.
        return 0.0;
    }
}
