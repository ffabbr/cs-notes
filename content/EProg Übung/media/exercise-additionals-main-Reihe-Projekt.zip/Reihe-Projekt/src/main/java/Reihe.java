public class Reihe {

    public static void main(String[] args) {
        int n = 4;
        double result = reihe(n);
        System.out.println(result);
    }

    public static double reihe(int seriesLimit) {
        // hier kommt unsere berechnung hin

        return 0.0;
    }


}
